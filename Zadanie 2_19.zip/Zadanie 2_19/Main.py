L = [12, 234, 456, 67, 7, 789, 10, 4, 23, 1]
L1 = [str(num) for num in L]
filled = [str(num).zfill(3) for num in L1]
napis = "".join(filled)
print(napis)