L = [12, 34, 56, 78, 89, 10, 11, 12, 13, 14, 15]
L1 = []
L1 = [str(num) for num in L]
napis = "".join(L1)
print (napis)