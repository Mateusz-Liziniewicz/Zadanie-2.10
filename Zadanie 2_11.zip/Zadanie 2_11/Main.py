word = "Brzęczyszczykiewicz"
word_zmienione = ""
for letter in word:
    word_zmienione += letter + "_"
print(word_zmienione)