line = ("To jest przykładowy\n tekst wielowierszowy\n w którym będziemy\n \tliczyć słowa")
words = line.split()
length = 0
length = sum(len(word)for word in words)
print (length)