line = ("To jest przykładowy\n tekst wielowierszowy\n w którym będziemy\n \tliczyć słowa ")
words = line.split()
pierwsze = ""
ostatnie = ""
for word in words:
    pierwsze += word[0]
    ostatnie += word[-1]
print(pierwsze)
print(ostatnie)
