number = 12350950475094586700954730607403700
string_number = str(number)
counted = string_number.count("0")
print(counted)