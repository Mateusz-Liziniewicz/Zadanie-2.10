line = "GvR jest twórcą Pythona. Należy zamienić GvR na tekst z treści zadania"
edited_line = line.replace("GvR", "Guido van Rossum")
print(edited_line)