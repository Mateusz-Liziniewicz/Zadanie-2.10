line = ("To jest przykładowy\n tekst wielowierszowy\n w którym będziemy\n \tliczyć słowa.")
print(line)
words = len(line.split())
print("Liczba wyrazów w tekście: ", words)